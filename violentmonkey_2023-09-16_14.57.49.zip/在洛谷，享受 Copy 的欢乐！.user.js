// ==UserScript==
// @name         在洛谷，享受 Copy 的欢乐！
// @namespace    https://www.luogu.com.cn/user/545986
// @version      1.0
// @description  将洛谷底部文本修改为"享受 Copy 的欢乐"
// @author       Jerrycyx & OpenAI-ChatGPT
// @match        https://www.luogu.com.cn/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=luogu.com.cn
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';
    const target = document.evaluate('/html/body/div[1]/div[2]/div[2]/div[2]/div[1]/text()[2]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    if (target) {
        target.textContent = "享受 Copy 的欢乐";
    }
})();
